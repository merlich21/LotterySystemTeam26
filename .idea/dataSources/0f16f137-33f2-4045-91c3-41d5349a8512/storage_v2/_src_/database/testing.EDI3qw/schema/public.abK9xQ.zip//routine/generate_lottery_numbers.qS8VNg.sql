create function generate_lottery_numbers() returns integer[]
    language plpgsql
as
$$
DECLARE
    result   INTEGER[] := ARRAY []::INTEGER[];
    next_num INTEGER;
BEGIN
    WHILE COALESCE(array_length(result, 1), 0) < 5
        LOOP
            next_num := floor(random() * 45 + 1)::INTEGER;

            IF NOT next_num = ANY (result) THEN
                result := array_append(result, next_num);
            END IF;
        END LOOP;

    RETURN result;
END;
$$;

alter function generate_lottery_numbers() owner to postgres;

